#!/usr/bin/python
#!/bin/bash
python index.py "$@"