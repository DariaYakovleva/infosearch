#!/bin/python
#!/bin/bash
python search.py "$@"